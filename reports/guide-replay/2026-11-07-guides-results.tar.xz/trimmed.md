# Innistrad draft guide

_Written by the nightly draft loop (`scripts/draft-loop/`) from 2026-11-07's lessons (trimmed: one-night stories and anecdotes removed) and every night's statistics. Drafters read it at every pick._

## Colours and archetypes

Eighteen nights: 144 decks, 535 games. Guided seats are 231-243 in games (49%, 92-100 in matches); unguided are 304-292 (51%, 124-116 in matches). Guided seats have not beaten unguided seats, so the guide has not been shown to help. Treat archetype lines as hypotheses and lean on the card numbers.

- BR: 57% of games (102 games, 14 decks, 27-15 in matches). Best pair by matches. Black removal plus a few real finishers.
- BG: 54% (152 games, 21 decks, 35-28 in matches). Needs evasion or removal-backed finishers and cheap creatures. Somberwald Spider and Spider Spawning beat ground decks.
- WR: 54% (101 games, 14 decks, 23-19 in matches). Cheap bodies, cheap removal and fliers, but it needs a late threat: WR decks have lost long grinds to Somberwald Spider or UB.
- WU: 51% (150 games, 20 decks, 30-30 in matches). White removal plus real fliers works; filler does not.
- WG: 50% (103 games, 14 decks, 22-20 in matches). Evasion alone does not win; removal count matters.
- RG: 50% (60 games, 8 decks, 12-12 in matches). Needs ways to reach fliers.
- WB: 44% (97 games, 13 decks, 17-22 in matches). Weak. Fliers and removal are not enough: it also needs cheap early blockers and enough sources for both colours.
- UB: 46% (139 games, 18 decks, 22-32 in matches). Needs cheap blockers, removal, and a stall-breaker (Moan of the Unhallowed, Murder of Crows). Do not take Delver of Secrets repeatedly.
- UR: 46% (112 games, 15 decks, 19-26 in matches). Still below average overall; take blue removal.
- Mono-colour: R 3-3 in matches (16 games).
- White is well supported on individual cards, but white pairs have not dominated. Cheap white removal (Rebuke) is contested, so take it early. Stay flexible on the second colour.
- Count playables before committing: pick a main colour by about pick 5 and a pair by mid pack 1 to mid pack 2. Do not leave a colour for one early removal spell unless the new colour is clearly open. If strong playables in one colour keep coming at picks 4-8, move in.
- Expect rivals to share commons (Victim of Night, Walking Corpse); take removal early.
- Evasion plus removal breaks stalls. Games stall for 13 to 55 turns.
- Splashing is poor.

## Commons that win

Deck game win rate for decks running the card.

- Green: Woodland Sleuth (160 games, 56%), Avacyn's Pilgrim (82 games, 55%, taken at 9.2), Villagers of Estwald (156 games, 54%), Prey Upon (159 games, 54%). Somberwald Spider is needed as a flier answer.
- Black: Typhoid Rats (200 games, 58%), Ghoulcaller's Chant (185 games, 54%, taken at 7.9), Victim of Night, Bump in the Night.
- White: Thraben Sentry (165 games, 58%, taken at 7.8), Unruly Mob (169 games, 56%, taken at 9.5), Bonds of Faith (196 games, 54%), Avacynian Priest (206 games, 53%), Selfless Cathar, Chapel Geist, Silverchase Fox.
- Red: Furor of the Bitten (65 games, 62%, taken at 10.7), Curse of the Pierced Heart (87 games, 57%, taken at 8.5), Ashmouth Hound (176 games, 57%), Traitorous Blood (65 games, 57%, taken at 9.9), Night Revelers (177 games, 54%).
- Blue: Spectral Flight (161 games, 53%), Hysterical Blindness, a late pick.
- Colourless: Silver-Inlaid Dagger (123 games, 55%, uncommon).
- Claustrophobia, Rebuke, Dead Weight, Tribute to Hunger, Brimstone Volley and Stitched Drake are praised in lessons and go early. Lessons from several decks credited cheap removal for wins, and the decks that cut it lost.

## Uncommons and rares

- Green: Spider Spawning (111 games, 60%), Gatstaf Shepherd (134 games, 57%), Lumberknot (117 games, 56%), Moldgraf Monstrosity (36 games, 58%, rare), Hollowhenge Scavenger.
- Black: Morkrut Banshee (108 games, 60%), Falkenrath Noble (109 games, 53%), Disciple of Griselbrand (96 games, 54%, taken at 8.7), Sever the Bloodline (earlier 31 games, 71%, rare).
- Red: Falkenrath Marauders (36 games, 75%, rare), Skirsdag Cultist (84 games, 61%, taken at 8.1), Stromkirk Noble (51 games, 59%, rare), Desperate Ravings (43 games, 56%, taken at 10.4), Into the Maw of Hell (151 games, 55%), Kruin Outlaw (74 games, 54%, rare), Rakish Heir (82 games, 54%).
- White: Elite Inquisitor (60 games, 60%, rare), Slayer of the Wicked (131 games, 60%), Mentor of the Meek (53 games, 58%, rare), Midnight Haunting (117 games, 57%), Rally the Peasants (78 games, 56%).
- Blue: Invisible Stalker (142 games, 55%).
- Colourless: Manor Gargoyle (69 games, 54%, rare), Galvanic Juggernaut (155 games, 55%, taken at 1.2; only average, so do not take it over removal or a strong on-colour card).
- Lands: Woodland Cemetery (41 games, 54%) in B/G. Moorland Haunt was 63% in 30 games earlier and comes late.

## Pick order

1. Cheap removal: Victim of Night, Dead Weight, Prey Upon, Sever the Bloodline, Claustrophobia, Tribute to Hunger, Rebuke, Brimstone Volley, Smite the Monstrous, Bonds of Faith, Sensory Deprivation, Corpse Lunge, Geistflame, Harvest Pyre. Take a second Dead Weight, Victim of Night or Brimstone Volley if offered. Aim for five or more removal spells. Take removal before Silverchase Fox or Abbey Griffin.
2. Strong uncommons and rares: Falkenrath Noble, Morkrut Banshee, Spider Spawning, Falkenrath Marauders, Slayer of the Wicked, Fiend Hunter, Mentor of the Meek, Elite Inquisitor, Stromkirk Noble, Murder of Crows (only if blue), Manor Gargoyle, Kruin Outlaw.
3. Evasive finishers and flier answers on colour: Chapel Geist, Voiceless Spirit, Stitched Drake, Spectral Rider, Abbey Griffin, Orchard Spirit, Moon Heron, Somberwald Spider. Aim for three evasive threats or a removal-backed finisher by the end of pack 3. Do not take an off-colour flier over an on-colour one.
4. Good cheap creatures: Typhoid Rats, Thraben Sentry, Elder Cathar, Woodland Sleuth, Villagers of Estwald, Ashmouth Hound, Bump in the Night, Unruly Mob, Selfless Cathar, Furor of the Bitten, Pitchburn Devils and Tormented Pariah if red, Silver-Inlaid Dagger.

Skip: Manor Skeleton, Armored Skaab, Cobbled Wings, Burning Vengeance, Think Twice, Night Terrors, Ghoulcaller's Bell, Wooden Stakes, Ancient Grudge, Traveler's Amulet, Runic Repetition, Wreath of Geists, Maw of the Mire, Graveyard Shovel, Inquisitor's Flail, Curse of Oblivion, Curse of the Bloody Tome, Lost in the Mist, Dissipate, Rooftop Storm, Fortress Crab, Rotting Fensnake, Gruesome Deformity, Mulch, Naturalize, Gnaw to the Bone, Memory's Journey, Festerhide Boar, Brain Weevil, Dream Twist, Cellar Door, Stensia Bloodhall, Creepy Doll, Cloistered Youth over a flier, Unburial Rites, and Makeshift Mauler as a second copy. Late in a pack, take a playable creature over an off-colour spell or a dead card. Avoid top-end bloat such as Markov Patrician.

## Building

- 17 lands is the default. Count pips for the heavier colour rather than copying a split.
- Avoid double pips in both colours, or give the double-pip colour at least 8 sources. Three GG Somberwald Spiders want 8+ Forests.
- Aim for four or more answers to fliers (that can also clear ground blockers) and at least two or three evasive or removal-backed finishers. Keep Prey Upon and Urgent Exorcism-type answers for opposing fliers.
- Keep one late threat or finisher.
- Removal alone is not enough: UB, WB and RG decks with plenty of removal still lost for lack of cheap, sturdy creatures.
- Cut weak third-colour cards for a clean two-colour core. Play the removal and flier answers you drafted; check every sideboard swap against your colours.
- Main fliers over filler such as Riot Devils (unless red is your main colour and deep), Walking Corpse or a marginal fourth creature.
- Do not main Naturalize, Gnaw to the Bone or Mulch. 1-toughness creatures die to Brimstone Volley and Geistflame.

## Playing

- Trade early, but hold Victim of Night, Dead Weight, Rebuke, Fiend Hunter and Smite the Monstrous for fliers and big blockers, not small ground bodies.
- Expect long games, often 20 to 40 turns, and up to 52. Break stalls with removal, Spider Spawning and evasive threats.
- Keep removal for Chapel Geist, Voiceless Spirit, Stitched Drake, Spectral Rider, Abbey Griffin, Angelic Overseer, Manor Gargoyle, Invisible Stalker, Moon Heron, Murder of Crows, Galvanic Juggernaut and Scourge of Geier Reach.
- Against WU, UB and UR, kill fliers early; Claustrophobia and Sensory Deprivation will target your best creature.
- Against WB, expect real removal held for your fliers; do not rely on one big threat.
- Against BG and WG, expect Typhoid Rats and Somberwald Spider to make the ground hard. Win in the air with removal backup and do not flood the board with ground bodies.
- Against WR, RG and BR, expect Brimstone Volley, Geistflame and Blasphemous Act to punish small creatures; do not overcommit into a sweeper and keep your own fliers alive.
